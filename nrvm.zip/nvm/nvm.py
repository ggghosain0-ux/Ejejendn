#!/usr/bin/env python3
"""
Nissal VMS v2.0 - KVM Edition
Custom Background Support
"""

import os, json, uuid, subprocess, signal, psutil, sqlite3, threading, time, shutil, socket, random, logging, warnings
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from contextlib import contextmanager

warnings.filterwarnings("ignore")
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

REQUIRED_CMDS = {
    'qemu-system-x86_64': 'qemu-system-x86',
    'qemu-img': 'qemu-utils',
    'cloud-localds': 'cloud-image-utils',
    'wget': 'wget',
    'curl': 'curl',
    'sshpass': 'sshpass'
}

def check_system_deps():
    missing_pkgs = []
    for cmd, pkg in REQUIRED_CMDS.items():
        if subprocess.run(['which', cmd], capture_output=True).returncode != 0:
            if pkg not in missing_pkgs: missing_pkgs.append(pkg)
    if missing_pkgs:
        print("\n" + "=" * 60)
        print("  ⚠️  MISSING: sudo apt install -y " + ' '.join(missing_pkgs))
        print("=" * 60 + "\n")
        return False
    return True

check_system_deps()

app = Flask(__name__)
@app.after_request
def add_header(response):
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['Content-Security-Policy'] = "default-src * 'unsafe-inline' 'unsafe-eval' data: blob:; media-src *; img-src * data:;"
    return response
app.secret_key = os.urandom(24).hex()
BASE_DIR = Path(__file__).parent.absolute()
VM_DIR = BASE_DIR / 'vm_instances'
DATABASE = str(BASE_DIR / 'nissal_vms.db')
VM_DIR.mkdir(exist_ok=True)

try: import paramiko; HAVE_PARAMIKO = True
except: HAVE_PARAMIKO = False

terminal_sessions = {}

def get_public_ip():
    try: return subprocess.check_output(['curl', '-s', 'ifconfig.me'], timeout=5).decode().strip()
    except: return 'localhost'

PUBLIC_IP = get_public_ip()

OS_TEMPLATES = {
    'ubuntu-22.04': {'name': 'Ubuntu 22.04', 'url': 'https://cloud-images.ubuntu.com/jammy/current/jammy-server-cloudimg-amd64.img', 'user': 'root', 'pass': 'nissal123'},
    'ubuntu-24.04': {'name': 'Ubuntu 24.04', 'url': 'https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-amd64.img', 'user': 'root', 'pass': 'nissal123'},
    'debian-12': {'name': 'Debian 12', 'url': 'https://cloud.debian.org/images/cloud/bookworm/latest/debian-12-generic-amd64.qcow2', 'user': 'root', 'pass': 'nissal123'},
}

def get_db_connection():
    conn = sqlite3.connect(DATABASE, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn

@contextmanager
def get_db():
    conn = get_db_connection()
    try: yield conn
    finally: conn.close()

def db_execute(query, params=None, fetch=False, fetchone=False):
    for attempt in range(5):
        try:
            conn = get_db_connection()
            cursor = conn.execute(query, params) if params else conn.execute(query)
            result = cursor.fetchall() if fetch else (cursor.fetchone() if fetchone else None)
            conn.commit(); conn.close()
            return result
        except sqlite3.OperationalError as e:
            if 'locked' in str(e) and attempt < 4: time.sleep(0.3*(attempt+1)); continue
            raise

def init_db():
    conn = sqlite3.connect(DATABASE, timeout=30)
    c = conn.cursor()
    c.execute("PRAGMA journal_mode=WAL")
    c.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT DEFAULT 'user', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, last_login TIMESTAMP, is_active BOOLEAN DEFAULT 1)''')
    c.execute('''CREATE TABLE IF NOT EXISTS vm_instances (id INTEGER PRIMARY KEY AUTOINCREMENT, vm_id TEXT UNIQUE NOT NULL, user_id INTEGER NOT NULL, name TEXT NOT NULL, os_template TEXT NOT NULL, ram_mb INTEGER NOT NULL, cpu_cores INTEGER NOT NULL, storage_gb INTEGER NOT NULL, ssh_port INTEGER, ssh_host TEXT, ssh_user TEXT, ssh_password TEXT, vnc_port INTEGER, status TEXT DEFAULT 'creating', pid INTEGER, tmate_ssh TEXT, tmate_web TEXT, creation_progress INTEGER DEFAULT 0, creation_step TEXT, notes TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE)''')
    c.execute('''CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, title TEXT NOT NULL, message TEXT NOT NULL, type TEXT DEFAULT 'info', is_read BOOLEAN DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    c.execute('''CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    c.execute('''CREATE TABLE IF NOT EXISTS audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, action TEXT NOT NULL, details TEXT, timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    defaults = [('site_name','NissRaj VMS'),('site_version','2.0'),('theme_color','#667eea'),('server_ip',PUBLIC_IP),('base_ssh_port','10000'),('base_vnc_port','5900'),('background_enabled','false'),('background_url','')]
    for k,v in defaults: c.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))
    try: c.execute("INSERT INTO users (username, email, password, role) VALUES (?,?,?,?)", ('admin','admin@nissraj.com',generate_password_hash('admin123',method='scrypt'),'admin'))
    except: pass
    conn.commit(); conn.close()

@app.context_processor
def inject_globals():
    def gs(k,d=None):
        try: r=db_execute("SELECT value FROM settings WHERE key=?",(k,),fetchone=True); return r['value'] if r else d
        except: return d
    return {
        'site_name':gs('site_name','NissRaj VMS'),
        'site_version':gs('site_version','2.0'),
        'theme_color':gs('theme_color','#667eea'),
        'get_setting':gs,
        'server_ip':gs('server_ip',PUBLIC_IP),
        'bg_enabled':gs('background_enabled','false'),
        'bg_url':gs('background_url','')
    }

def login_required(f):
    @wraps(f)
    def d(*a,**k):
        if 'user_id' not in session: flash('Please login first.','warning'); return redirect(url_for('login'))
        return f(*a,**k)
    return d

def admin_required(f):
    @wraps(f)
    def d(*a,**k):
        if 'user_id' not in session: return redirect(url_for('login'))
        if session.get('role')!='admin': flash('Admin only.','danger'); return redirect(url_for('dashboard'))
        return f(*a,**k)
    return d

def vm_owner_or_admin(f):
    @wraps(f)
    def d(*a,**k):
        if 'user_id' not in session: return redirect(url_for('login'))
        vm_id=k.get('vm_id')
        vm=db_execute("SELECT user_id FROM vm_instances WHERE vm_id=?",(vm_id,),fetchone=True)
        if not vm: flash('VM not found.','danger'); return redirect(url_for('dashboard'))
        if session['role']!='admin' and vm['user_id']!=session['user_id']: flash('Access denied.','danger'); return redirect(url_for('dashboard'))
        return f(*a,**k)
    return d

def add_notification(uid,t,m,ty='info'):
    try: db_execute("INSERT INTO notifications (user_id,title,message,type) VALUES (?,?,?,?)",(uid,t,m,ty))
    except: pass

def gsv(k,d=None):
    try: r=db_execute("SELECT value FROM settings WHERE key=?",(k,),fetchone=True); return r['value'] if r else d
    except: return d

def get_random_port():
    used = db_execute("SELECT ssh_port FROM vm_instances", fetch=True) or []
    used_ports = {r['ssh_port'] for r in used}
    for _ in range(100):
        port = random.randint(10000, 65535)
        if port not in used_ports: return port
    port = 10000
    while port in used_ports: port += 1
    return port

class VMManager:
    def __init__(self): self.base=VM_DIR
    def vm_dir(self,vid): d=self.base/vid; d.mkdir(exist_ok=True); return d
    def up(self,vid,p,s):
        try: db_execute("UPDATE vm_instances SET creation_progress=?, creation_step=? WHERE vm_id=?",(p,s,vid))
        except: pass
    
    def download_image(self,vid,ost):
        d=self.vm_dir(vid); img=d/'disk.qcow2'
        if img.exists(): return str(img)
        oi=OS_TEMPLATES.get(ost,OS_TEMPLATES['ubuntu-22.04']); raw=d/'disk.img'
        self.up(vid,10,'Downloading OS image...')
        subprocess.run(['wget','-q','--show-progress','-O',str(raw),oi['url']],check=False)
        self.up(vid,40,'Converting...')
        subprocess.run(['qemu-img','convert','-f','qcow2','-O','qcow2',str(raw),str(img)],check=False)
        if raw.exists(): raw.unlink()
        self.up(vid,60,'Image ready'); return str(img)
    
    def resize_disk(self,vid,sz):
        d=self.vm_dir(vid); img=d/'disk.qcow2'
        if img.exists():
            self.up(vid,65,f'Resizing disk to {sz}GB...')
            subprocess.run(['qemu-img','resize',str(img),f'{sz}G'],capture_output=True)
            self.up(vid,70,f'Disk resized to {sz}GB')
    
    def create_cloud_init(self,vid,ost,hn,pw):
        d=self.vm_dir(vid); seed=d/'seed.iso'
        self.up(vid,75,'Creating cloud-init...')
        ud=f"""#cloud-config
hostname: {hn}
disable_root: false
ssh_pwauth: true
growpart:
  mode: auto
  devices: ['/']
resize_rootfs: true
chpasswd:
  list: |
    root:{pw}
  expire: false
users:
  - name: root
    lock_passwd: false
    shell: /bin/bash
    sudo: ALL=(ALL) NOPASSWD:ALL
write_files:
  - path: /etc/ssh/sshd_config.d/nissal.conf
    content: |
      PermitRootLogin yes
      PasswordAuthentication yes
packages: [cloud-guest-utils, curl, wget, git, vim, htop, net-tools, openssh-server, tmate]
bootcmd:
  - echo 'root:{pw}' | chpasswd
  - growpart /dev/vda 1 || growpart /dev/sda 1 || true
  - resize2fs /dev/vda1 || resize2fs /dev/sda1 || true
runcmd:
  - echo 'root:{pw}' | chpasswd
  - growpart /dev/vda 1 || growpart /dev/sda 1 || true
  - resize2fs /dev/vda1 || resize2fs /dev/sda1 || true
  - sed -i 's/#PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
  - sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config
  - systemctl restart ssh 2>/dev/null || service ssh restart 2>/dev/null
"""
        md=f"instance-id: {vid}\nlocal-hostname: {hn}\n"
        (d/'user-data').write_text(ud); (d/'meta-data').write_text(md)
        self.up(vid,80,'Generating seed ISO...')
        if seed.exists(): seed.unlink()
        subprocess.run(['cloud-localds',str(seed),str(d/'user-data'),str(d/'meta-data')],check=False)
        return str(seed)
    
    def start_vm(self,vid,ost,ram,cpu,stor,sp,vp):
        d=self.vm_dir(vid); img=d/'disk.qcow2'; seed=d/'seed.iso'
        pf=d/'qemu.pid'
        subprocess.run(['fuser','-k',f'{sp}/tcp'],capture_output=True); time.sleep(1)
        if pf.exists():
            try: os.kill(int(pf.read_text().strip()),signal.SIGKILL)
            except: pass
            pf.unlink()
        subprocess.run(['pkill','-f',f'qemu.*{vid[:8]}'],capture_output=True); time.sleep(1)
        qc=['qemu-system-x86_64','-name',vid,'-m',str(ram),'-smp',str(cpu),'-cpu','host','-enable-kvm','-drive',f'file={img},format=qcow2,if=virtio','-drive',f'file={seed},format=raw,if=virtio','-netdev',f'user,id=net0,hostfwd=tcp::{sp}-:22','-device','virtio-net-pci,netdev=net0','-vnc',f'0.0.0.0:{vp-5900}','-daemonize','-pidfile',str(pf)]
        subprocess.Popen(qc,stdout=subprocess.PIPE,stderr=subprocess.PIPE).wait()
        for i in range(15):
            if pf.exists():
                try: pid=int(pf.read_text().strip()); os.kill(pid,0); return pid
                except: pass
            time.sleep(1)
        try:
            r=subprocess.run(['pgrep','-f',f'qemu.*{vid[:8]}'],capture_output=True,text=True)
            if r.stdout.strip(): pid=int(r.stdout.strip().split('\n')[0]); pf.write_text(str(pid)); return pid
        except: pass
        return None
    
    def stop_vm(self,pid,sp=None):
        if sp: subprocess.run(['fuser','-k',f'{sp}/tcp'],capture_output=True)
        if not pid: return True
        try: os.kill(pid,signal.SIGTERM); time.sleep(3)
        except: pass
        try: os.kill(pid,signal.SIGKILL)
        except: pass
        return True
    
    def vm_status(self,vid):
        pf=self.vm_dir(vid)/'qemu.pid'
        if pf.exists():
            try: pid=int(pf.read_text().strip()); os.kill(pid,0); return True,pid
            except: pf.unlink()
        try:
            r=subprocess.run(['pgrep','-f',f'qemu.*{vid[:8]}'],capture_output=True,text=True)
            if r.stdout.strip(): pid=int(r.stdout.strip().split('\n')[0]); pf.write_text(str(pid)); return True,pid
        except: pass
        return False,None
    
    def vm_metrics(self,pid):
        if not pid: return None
        try:
            p=psutil.Process(pid); mem=p.memory_info()
            return {'cpu':round(p.cpu_percent(interval=1),1),'ram_mb':round(mem.rss/(1024*1024),0),'threads':p.num_threads(),'uptime':str(datetime.now()-datetime.fromtimestamp(p.create_time()))}
        except: return None
    
    def ssh_exec(self,sp,cmd,to=30):
        try:
            c=f"sshpass -p 'nissal123' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 -p {sp} root@127.0.0.1 '{cmd}'"
            r=subprocess.run(c,shell=True,capture_output=True,text=True,timeout=to)
            return r.stdout if r.returncode==0 else r.stderr
        except: return "Connection failed"
    
    def setup_tmate(self,vid,sp):
        try:
            for i in range(30):
                r=subprocess.run(['sshpass','-p','nissal123','ssh','-o','StrictHostKeyChecking=no','-o','ConnectTimeout=3','-p',str(sp),'root@127.0.0.1','echo READY'],capture_output=True,text=True,timeout=10)
                if 'READY' in r.stdout: break
                time.sleep(2)
            sn=f'/tmp/tmate-{uuid.uuid4().hex[:8]}.sock'
            c=(f"sshpass -p 'nissal123' ssh -o StrictHostKeyChecking=no -p {sp} root@127.0.0.1 "
               f"'apt-get update -qq 2>/dev/null; apt-get install -y -qq tmate 2>/dev/null; "
               f"tmate -S {sn} new-session -d 2>/dev/null; sleep 3; "
               f"tmate -S {sn} display -p \"#{{tmate_ssh}}\" 2>/dev/null; echo ---; "
               f"tmate -S {sn} display -p \"#{{tmate_web}}\" 2>/dev/null'")
            r=subprocess.run(c,shell=True,capture_output=True,text=True,timeout=120)
            if '---' in r.stdout:
                pts=r.stdout.strip().split('---')
                ssh=pts[0].strip() if len(pts)>0 else None; web=pts[1].strip() if len(pts)>1 else None
                if ssh or web:
                    db_execute("UPDATE vm_instances SET tmate_ssh=?, tmate_web=? WHERE vm_id=?",(ssh,web,vid))
                    return {'ssh':ssh,'web':web}
        except: pass
        return None

vm=VMManager()

def complete_vm_setup(vid,ost,ram,cpu,stor,sp,vp):
    try:
        vm.download_image(vid,ost); vm.resize_disk(vid,stor)
        vm.create_cloud_init(vid,ost,f'nissal-{vid[:8]}','nissal123')
        vm.up(vid,85,'Starting VM...')
        pid=vm.start_vm(vid,ost,ram,cpu,stor,sp,vp)
        conn=get_db_connection()
        if pid:
            conn.execute("UPDATE vm_instances SET status='running', pid=?, creation_progress=100 WHERE vm_id=?",(pid,vid))
            v=conn.execute("SELECT * FROM vm_instances WHERE vm_id=?",(vid,)).fetchone()
            if v: conn.execute("INSERT INTO notifications (user_id,title,message,type) VALUES (?,?,?,?)",(v['user_id'],'VM Ready!',f'VM "{v["name"]}" running! Port: {sp}','success'))
        else:
            time.sleep(3); pid=vm.start_vm(vid,ost,ram,cpu,stor,sp,vp)
            if pid: conn.execute("UPDATE vm_instances SET status='running', pid=?, creation_progress=100 WHERE vm_id=?",(pid,vid))
            else: conn.execute("UPDATE vm_instances SET status='stopped', creation_progress=100 WHERE vm_id=?",(vid,))
        conn.commit(); conn.close()
        if pid:
            time.sleep(10)
            try: vm.ssh_exec(sp,'growpart /dev/vda 1 || growpart /dev/sda 1 || true'); vm.ssh_exec(sp,'resize2fs /dev/vda1 || resize2fs /dev/sda1 || true')
            except: pass
    except Exception as e:
        print(f"Setup error: {e}")

# ==================== ROUTES ====================
@app.route('/')
def index(): return redirect(url_for('dashboard' if 'user_id' in session else 'login'))

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        u=request.form.get('username','').strip(); p=request.form.get('password','')
        user=db_execute("SELECT * FROM users WHERE username=? AND is_active=1",(u,),fetchone=True)
        if user and check_password_hash(user['password'],p):
            session['user_id']=user['id']; session['username']=user['username']; session['role']=user['role']
            session.permanent=True; db_execute("UPDATE users SET last_login=CURRENT_TIMESTAMP WHERE id=?",(user['id'],))
            flash(f'Welcome!','success')
            return redirect(url_for('admin_dashboard' if user['role']=='admin' else 'dashboard'))
        flash('Invalid credentials.','danger')
    return render_template('login.html')

@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=='POST':
        u=request.form.get('username','').strip(); e=request.form.get('email','').strip(); p=request.form.get('password','')
        if len(p)<6: flash('Password too short.','warning'); return render_template('register.html')
        try:
            db_execute("INSERT INTO users (username,email,password) VALUES (?,?,?)",(u,e,generate_password_hash(p,method='scrypt')))
            flash('Registered!','success'); return redirect(url_for('login'))
        except: flash('Username/email exists.','danger')
    return render_template('register.html')

@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    vms=db_execute("SELECT * FROM vm_instances WHERE user_id=? ORDER BY created_at DESC",(session['user_id'],),fetch=True) or []
    notifs=db_execute("SELECT * FROM notifications WHERE user_id=? AND is_read=0 ORDER BY created_at DESC LIMIT 5",(session['user_id'],),fetch=True) or []
    vl=[]
    for v in vms: d=dict(v); r,_=vm.vm_status(v['vm_id']); d['real_status']='running' if r else ('creating' if v['status']=='creating' else 'stopped'); vl.append(d)
    return render_template('dashboard.html',vms=vl,notifications=notifs)

@app.route('/vm/create',methods=['GET','POST'])
@admin_required
def create_vm():
    if request.method=='POST':
        name=request.form.get('name','').strip(); ost=request.form.get('os_template','ubuntu-22.04')
        ram=int(request.form.get('ram_mb',2048)); cpu=int(request.form.get('cpu_cores',2))
        stor=int(request.form.get('storage_gb',20)); uid=int(request.form.get('user_id',session['user_id']))
        custom_port=request.form.get('ssh_port','').strip()
        if not name: flash('VM name required.','warning'); return redirect(url_for('create_vm'))
        vid=str(uuid.uuid4())
        if custom_port:
            sp=int(custom_port)
            if sp<22 or sp>65535: flash('Port must be 22-65535.','danger'); return redirect(url_for('create_vm'))
            ex=db_execute("SELECT COUNT(*) as c FROM vm_instances WHERE ssh_port=?",(sp,),fetchone=True)
            if ex and ex['c']>0: flash(f'Port {sp} is already in use!','danger'); return redirect(url_for('create_vm'))
        else: sp=get_random_port()
        vp=int(gsv('base_vnc_port',5900))+(sp-10000)
        db_execute('''INSERT INTO vm_instances (vm_id,user_id,name,os_template,ram_mb,cpu_cores,storage_gb,ssh_port,ssh_host,ssh_user,ssh_password,vnc_port,status,creation_step) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(vid,uid,name,ost,ram,cpu,stor,sp,PUBLIC_IP,'root','nissal123',vp,'creating','Starting...'))
        add_notification(uid,'VM Creating...',f'VM "{name}" - Port: {sp}','info')
        threading.Thread(target=complete_vm_setup,args=(vid,ost,ram,cpu,stor,sp,vp),daemon=True).start()
        flash(f'VM "{name}" created! Port: {sp}','success'); return redirect(url_for('admin_vms'))
    users=db_execute("SELECT id,username FROM users WHERE is_active=1 ORDER BY username",fetch=True) or []
    return render_template('create_vm.html',os_templates=OS_TEMPLATES,users=users)

@app.route('/vm/<vm_id>/manage')
@login_required
@vm_owner_or_admin
def manage_vm(vm_id):
    v=db_execute("SELECT * FROM vm_instances WHERE vm_id=?",(vm_id,),fetchone=True)
    r,pid=vm.vm_status(vm_id); m=vm.vm_metrics(pid) if r else None
    return render_template('manage_vm.html',vm=v,is_running=r,metrics=m)

@app.route('/vm/<vm_id>/terminal')
@login_required
@vm_owner_or_admin
def web_terminal(vm_id):
    v=db_execute("SELECT * FROM vm_instances WHERE vm_id=?",(vm_id,),fetchone=True)
    if not v: flash('VM not found.','danger'); return redirect(url_for('dashboard'))
    r,_=vm.vm_status(vm_id)
    if not r: flash('VM is not running.','warning'); return redirect(url_for('manage_vm',vm_id=vm_id))
    return render_template('terminal.html',vm=v)

@app.route('/vm/<vm_id>/terminal/connect', methods=['POST'])
@login_required
@vm_owner_or_admin
def terminal_connect(vm_id):
    if not HAVE_PARAMIKO: return jsonify({'success': False, 'message': 'paramiko not installed'})
    data = request.json
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect('127.0.0.1', port=int(data.get('port',22)), username=data.get('username','root'), 
                   password=data.get('password','nissal123'), look_for_keys=False, allow_agent=False, timeout=10)
        channel = ssh.invoke_shell(term='xterm-256color', width=120, height=40)
        channel.settimeout(0.1)
        session_id = str(uuid.uuid4())
        terminal_sessions[session_id] = {'ssh': ssh, 'channel': channel, 'created': time.time()}
        time.sleep(0.3)
        output = ''
        try:
            for _ in range(5):
                if channel.recv_ready():
                    output += channel.recv(4096).decode('utf-8', errors='replace')
                time.sleep(0.1)
        except: pass
        return jsonify({'success': True, 'session': session_id, 'output': output})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/vm/<vm_id>/terminal/read', methods=['POST'])
@login_required
@vm_owner_or_admin
def terminal_read(vm_id):
    data = request.json
    session_id = data.get('session')
    if session_id not in terminal_sessions: return jsonify({'output': '', 'closed': True})
    session = terminal_sessions[session_id]
    channel = session['channel']
    output = ''
    try:
        for _ in range(3):
            if channel.recv_ready():
                output += channel.recv(4096).decode('utf-8', errors='replace')
            time.sleep(0.05)
        if channel.closed:
            try: session['ssh'].close()
            except: pass
            del terminal_sessions[session_id]
            return jsonify({'output': output, 'closed': True})
    except:
        try: session['ssh'].close()
        except: pass
        if session_id in terminal_sessions: del terminal_sessions[session_id]
        return jsonify({'output': '', 'closed': True})
    return jsonify({'output': output, 'closed': False})

@app.route('/vm/<vm_id>/terminal/send', methods=['POST'])
@login_required
@vm_owner_or_admin
def terminal_send(vm_id):
    data = request.json
    session_id = data.get('session')
    if session_id in terminal_sessions:
        try: terminal_sessions[session_id]['channel'].send(data.get('data', ''))
        except: pass
    return jsonify({'success': True})

@app.route('/vm/<vm_id>/start')
@login_required
@vm_owner_or_admin
def start_vm_route(vm_id):
    v=db_execute("SELECT * FROM vm_instances WHERE vm_id=?",(vm_id,),fetchone=True)
    if not v: return jsonify({'success':False,'message':'VM not found'})
    r,_=vm.vm_status(vm_id)
    if r: return jsonify({'success':False,'message':'Already running'})
    subprocess.run(['fuser','-k',f'{v["ssh_port"]}/tcp'],capture_output=True); time.sleep(1)
    pid=vm.start_vm(vm_id,v['os_template'],v['ram_mb'],v['cpu_cores'],v['storage_gb'],v['ssh_port'],v['vnc_port'])
    if pid: db_execute("UPDATE vm_instances SET status='running', pid=? WHERE vm_id=?",(pid,vm_id)); return jsonify({'success':True,'message':'VM started!'})
    time.sleep(2); pid=vm.start_vm(vm_id,v['os_template'],v['ram_mb'],v['cpu_cores'],v['storage_gb'],v['ssh_port'],v['vnc_port'])
    if pid: db_execute("UPDATE vm_instances SET status='running', pid=? WHERE vm_id=?",(pid,vm_id)); return jsonify({'success':True,'message':'VM started!'})
    return jsonify({'success':False,'message':'Failed'})

@app.route('/vm/<vm_id>/stop')
@login_required
@vm_owner_or_admin
def stop_vm_route(vm_id):
    v=db_execute("SELECT * FROM vm_instances WHERE vm_id=?",(vm_id,),fetchone=True)
    if not v: return jsonify({'success':False})
    r,pid=vm.vm_status(vm_id)
    if not r: return jsonify({'success':False,'message':'Not running'})
    if vm.stop_vm(pid,v['ssh_port']): db_execute("UPDATE vm_instances SET status='stopped', pid=NULL WHERE vm_id=?",(vm_id,)); return jsonify({'success':True,'message':'Stopped'})
    return jsonify({'success':False})

@app.route('/vm/<vm_id>/restart')
@login_required
@vm_owner_or_admin
def restart_vm_route(vm_id):
    v=db_execute("SELECT * FROM vm_instances WHERE vm_id=?",(vm_id,),fetchone=True)
    if not v: return jsonify({'success':False})
    r,pid=vm.vm_status(vm_id)
    if r: vm.stop_vm(pid,v['ssh_port']); time.sleep(3)
    subprocess.run(['fuser','-k',f'{v["ssh_port"]}/tcp'],capture_output=True); time.sleep(1)
    np=vm.start_vm(vm_id,v['os_template'],v['ram_mb'],v['cpu_cores'],v['storage_gb'],v['ssh_port'],v['vnc_port'])
    if np: db_execute("UPDATE vm_instances SET status='running', pid=? WHERE vm_id=?",(np,vm_id)); return jsonify({'success':True,'message':'Restarted!'})
    return jsonify({'success':False})

@app.route('/vm/<vm_id>/delete')
@admin_required
def delete_vm_route(vm_id):
    v=db_execute("SELECT * FROM vm_instances WHERE vm_id=?",(vm_id,),fetchone=True)
    if not v: return jsonify({'success':False})
    r,pid=vm.vm_status(vm_id)
    if r: vm.stop_vm(pid,v['ssh_port'])
    subprocess.run(['fuser','-k',f'{v["ssh_port"]}/tcp'],capture_output=True)
    subprocess.run(['pkill','-9','-f',f'qemu.*{vm_id[:8]}'],capture_output=True)
    shutil.rmtree(VM_DIR/vm_id,ignore_errors=True)
    db_execute("DELETE FROM vm_instances WHERE vm_id=?",(vm_id,))
    return jsonify({'success':True})

@app.route('/vm/<vm_id>/tmate')
@login_required
@vm_owner_or_admin
def tmate_route(vm_id):
    v=db_execute("SELECT * FROM vm_instances WHERE vm_id=?",(vm_id,),fetchone=True)
    if not v: return jsonify({'success':False,'message':'VM not found'})
    r,_=vm.vm_status(vm_id)
    if not r: return jsonify({'success':False,'message':'Start VM first'})
    res=vm.setup_tmate(vm_id,v['ssh_port'])
    if res: return jsonify({'success':True,'tmate_ssh':res['ssh'],'tmate_web':res['web']})
    return jsonify({'success':False,'message':'Try again'})

@app.route('/vm/<vm_id>/metrics')
@login_required
@vm_owner_or_admin
def metrics_route(vm_id):
    v=db_execute("SELECT * FROM vm_instances WHERE vm_id=?",(vm_id,),fetchone=True)
    if not v: return jsonify({'success':False})
    r,pid=vm.vm_status(vm_id)
    if r: return jsonify({'success':True,'running':True,'metrics':vm.vm_metrics(pid)})
    return jsonify({'success':True,'running':False})

@app.route('/vm/<vm_id>/edit',methods=['GET','POST'])
@admin_required
def edit_vm(vm_id):
    v=db_execute("SELECT * FROM vm_instances WHERE vm_id=?",(vm_id,),fetchone=True)
    if not v: flash('VM not found.','danger'); return redirect(url_for('admin_vms'))
    if request.method=='POST':
        new_port=int(request.form.get('ssh_port',v['ssh_port']))
        if new_port!=v['ssh_port']:
            ex=db_execute("SELECT COUNT(*) as c FROM vm_instances WHERE ssh_port=? AND vm_id!=?",(new_port,vm_id),fetchone=True)
            if ex and ex['c']>0: flash(f'Port {new_port} is already in use!','danger'); return redirect(url_for('admin_vms'))
        db_execute("UPDATE vm_instances SET name=?, ram_mb=?, cpu_cores=?, storage_gb=?, notes=?, user_id=?, ssh_port=? WHERE vm_id=?",(request.form.get('name','').strip(),int(request.form.get('ram_mb',v['ram_mb'])),int(request.form.get('cpu_cores',v['cpu_cores'])),int(request.form.get('storage_gb',v['storage_gb'])),request.form.get('notes',''),int(request.form.get('user_id',v['user_id'])),new_port,vm_id))
        flash('Updated!','success'); return redirect(url_for('admin_vms'))
    users=db_execute("SELECT id,username FROM users WHERE is_active=1 ORDER BY username",fetch=True) or []
    return render_template('edit_vm.html',vm=v,users=users)

@app.route('/admin')
@admin_required
def admin_dashboard():
    tv=(db_execute("SELECT COUNT(*) as c FROM vm_instances",fetchone=True) or {'c':0})['c']
    rv=(db_execute("SELECT COUNT(*) as c FROM vm_instances WHERE status='running'",fetchone=True) or {'c':0})['c']
    tu=(db_execute("SELECT COUNT(*) as c FROM users",fetchone=True) or {'c':0})['c']
    cpu=psutil.cpu_percent(); mem=psutil.virtual_memory(); disk=psutil.disk_usage('/')
    return render_template('admin/dashboard.html',total_vms=tv,running_vms=rv,total_users=tu,cpu_percent=cpu,memory_percent=mem.percent,memory_used=round(mem.used/(1024**3),1),memory_total=round(mem.total/(1024**3),1),disk_percent=disk.percent)

@app.route('/admin/vms')
@admin_required
def admin_vms():
    vms=db_execute("SELECT v.*, u.username FROM vm_instances v JOIN users u ON v.user_id=u.id ORDER BY v.created_at DESC",fetch=True) or []
    vl=[]
    for v in vms: d=dict(v); r,_=vm.vm_status(v['vm_id']); d['real_status']='running' if r else v['status']; vl.append(d)
    return render_template('admin/vms.html',vms=vl)

@app.route('/admin/users')
@admin_required
def admin_users():
    users=db_execute("SELECT u.*, COUNT(v.id) as vm_count FROM users u LEFT JOIN vm_instances v ON u.id=v.user_id GROUP BY u.id ORDER BY u.created_at DESC",fetch=True) or []
    return render_template('admin/users.html',users=users)

@app.route('/admin/users/create',methods=['GET','POST'])
@admin_required
def admin_create_user():
    if request.method=='POST':
        try:
            db_execute("INSERT INTO users (username,email,password,role) VALUES (?,?,?,?)",(request.form['username'],request.form['email'],generate_password_hash(request.form['password'],method='scrypt'),request.form.get('role','user')))
            flash('User created!','success'); return redirect(url_for('admin_users'))
        except: flash('Username/email exists.','danger')
    return render_template('admin/create_user.html')

@app.route('/admin/users/<int:user_id>/edit',methods=['GET','POST'])
@admin_required
def admin_edit_user(user_id):
    u=db_execute("SELECT * FROM users WHERE id=?",(user_id,),fetchone=True)
    if not u: flash('Not found.','danger'); return redirect(url_for('admin_users'))
    if request.method=='POST':
        pw=request.form.get('new_password','')
        if pw: db_execute("UPDATE users SET username=?,email=?,role=?,is_active=?,password=? WHERE id=?",(request.form['username'],request.form['email'],request.form.get('role','user'),request.form.get('is_active')=='on',generate_password_hash(pw,method='scrypt'),user_id))
        else: db_execute("UPDATE users SET username=?,email=?,role=?,is_active=? WHERE id=?",(request.form['username'],request.form['email'],request.form.get('role','user'),request.form.get('is_active')=='on',user_id))
        flash('Updated!','success'); return redirect(url_for('admin_users'))
    return render_template('admin/edit_user.html',user=u)

@app.route('/admin/users/<int:user_id>/delete')
@admin_required
def admin_delete_user(user_id):
    if user_id==session['user_id']: flash('Cannot delete yourself.','danger'); return redirect(url_for('admin_users'))
    u=db_execute("SELECT * FROM users WHERE id=?",(user_id,),fetchone=True)
    if u:
        for v in (db_execute("SELECT vm_id FROM vm_instances WHERE user_id=?",(user_id,),fetch=True) or []):
            r,p=vm.vm_status(v['vm_id'])
            if r: vm.stop_vm(p)
            subprocess.run(['fuser','-k',f'{v["ssh_port"]}/tcp'],capture_output=True)
            subprocess.run(['pkill','-9','-f',f'qemu.*{v["vm_id"][:8]}'],capture_output=True)
            shutil.rmtree(VM_DIR/v['vm_id'],ignore_errors=True)
        db_execute("DELETE FROM notifications WHERE user_id=?",(user_id,))
        db_execute("DELETE FROM vm_instances WHERE user_id=?",(user_id,))
        db_execute("DELETE FROM users WHERE id=?",(user_id,))
        flash('Deleted.','success')
    return redirect(url_for('admin_users'))

@app.route('/admin/settings',methods=['GET','POST'])
@admin_required
def admin_settings():
    if request.method=='POST':
        for k,v in request.form.items():
            if k.startswith('setting_'): db_execute("UPDATE settings SET value=?, updated_at=CURRENT_TIMESTAMP WHERE key=?",(v,k.replace('setting_','')))
        flash('Saved!','success'); return redirect(url_for('admin_settings'))
    return render_template('admin/settings.html',settings=db_execute("SELECT * FROM settings ORDER BY key",fetch=True) or [])

@app.route('/admin/audit')
@admin_required
def admin_audit():
    return render_template('admin/audit.html',logs=db_execute("SELECT a.*, u.username FROM audit_log a LEFT JOIN users u ON a.user_id=u.id ORDER BY a.timestamp DESC LIMIT 100",fetch=True) or [])

@app.route('/profile')
@login_required
def profile():
    u=db_execute("SELECT * FROM users WHERE id=?",(session['user_id'],),fetchone=True)
    c=(db_execute("SELECT COUNT(*) as c FROM vm_instances WHERE user_id=?",(session['user_id'],),fetchone=True) or {'c':0})['c']
    return render_template('profile.html',user=u,vm_count=c)

@app.route('/profile/update',methods=['POST'])
@login_required
def update_profile():
    pw=request.form.get('new_password','')
    if pw: db_execute("UPDATE users SET email=?, password=? WHERE id=?",(request.form['email'],generate_password_hash(pw,method='scrypt'),session['user_id']))
    else: db_execute("UPDATE users SET email=? WHERE id=?",(request.form['email'],session['user_id']))
    flash('Updated!','success'); return redirect(url_for('profile'))

@app.route('/notifications')
@login_required
def notifications():
    return render_template('notifications.html',notifications=db_execute("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50",(session['user_id'],),fetch=True) or [])

@app.route('/notifications/read/<int:nid>')
@login_required
def read_notification(nid):
    db_execute("UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?",(nid,session['user_id']))
    return jsonify({'success':True})

@app.errorhandler(404)
def e404(e): return render_template('errors/404.html'),404
@app.errorhandler(500)
def e500(e): return render_template('errors/500.html'),500

@app.template_filter('datetime')
def dt_fmt(v):
    if v:
        if isinstance(v,str):
            try: return datetime.strptime(v,'%Y-%m-%d %H:%M:%S').strftime('%Y-%m-%d %H:%M:%S')
            except: return v
        return v.strftime('%Y-%m-%d %H:%M:%S')
    return 'N/A'

if __name__=='__main__':
    init_db()
    print(f"\n{'='*45}")
    print(f"  Nissal VMS v2.0")
    print(f"  URL: http://{PUBLIC_IP}:5000")
    print(f"  Login: admin / admin123")
    print(f"{'='*45}\n")
    app.run(host='0.0.0.0',port=5000,debug=False,threaded=True)